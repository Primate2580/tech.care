import PlaceholderPage from '../components/PlaceholderPage.jsx';

export default function Message() {
  return <PlaceholderPage title="Message">The messages page is built in Step 5.</PlaceholderPage>;
}
