import PlaceholderPage from '../components/PlaceholderPage.jsx';

export default function Overview() {
  return <PlaceholderPage title="Overview">The overview dashboard is built in Step 5.</PlaceholderPage>;
}
