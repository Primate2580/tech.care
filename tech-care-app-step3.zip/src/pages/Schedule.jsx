import PlaceholderPage from '../components/PlaceholderPage.jsx';

export default function Schedule() {
  return <PlaceholderPage title="Schedule">The schedule page is built in Step 5.</PlaceholderPage>;
}
