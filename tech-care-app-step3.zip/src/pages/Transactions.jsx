import PlaceholderPage from '../components/PlaceholderPage.jsx';

export default function Transactions() {
  return <PlaceholderPage title="Transactions">The transactions page is built in Step 5.</PlaceholderPage>;
}
