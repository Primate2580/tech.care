import { useEffect, useState } from 'react';
import { fetchPatients } from '../lib/api.js';
import { PatientsContext } from './PatientsContext.js';

/** Fetches the patient list once so every page shares it (no refetch when navigating). */
export default function PatientsProvider({ children }) {
  const [state, setState] = useState({ status: 'loading', patients: [], error: null });

  useEffect(() => {
    const controller = new AbortController();
    fetchPatients(controller.signal)
      .then((patients) => setState({ status: 'ready', patients, error: null }))
      .catch((error) => {
        if (error.name !== 'AbortError') setState({ status: 'error', patients: [], error });
      });
    return () => controller.abort();
  }, []);

  return <PatientsContext.Provider value={state}>{children}</PatientsContext.Provider>;
}
