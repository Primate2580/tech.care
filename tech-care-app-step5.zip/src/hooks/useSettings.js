import { useContext } from 'react';
import { SettingsContext } from '../context/SettingsContext.js';

export function useSettings() {
  const context = useContext(SettingsContext);
  if (!context) throw new Error('useSettings must be used inside <SettingsProvider>');
  return context;
}
