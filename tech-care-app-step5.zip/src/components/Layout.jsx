import { Outlet } from 'react-router';
import Header from './Header.jsx';
import { usePatients } from '../hooks/usePatients.js';

/** Shell shared by every route: header on top, the current page below. */
export default function Layout() {
  const { status } = usePatients();

  return (
    <div className="mx-auto max-w-[1600px] p-[18px]">
      <Header />
      {status === 'error' && (
        <p role="alert" className="mt-[18px] rounded-xl bg-white p-4 text-center font-bold">
          Sorry, the patient data could not be loaded. Please refresh to try again.
        </p>
      )}
      <div className="mt-[18px]">
        <Outlet />
      </div>
    </div>
  );
}
