export default function Avatar({ patient, className = 'size-12' }) {
  return (
    <img
      src={patient.profile_picture}
      alt=""
      width="48"
      height="48"
      loading="lazy"
      className={`${className} shrink-0 rounded-full object-cover`}
    />
  );
}
