# Tech.Care

A patient dashboard built with React, React Router, Tailwind CSS v4 and Chart.js.
It started as a pixel-matched Adobe XD conversion for a front-end skills test and was then
extended into a multi-page app.

## Features

- **Patients** (`/patients/:name`): sidebar with search, blood pressure chart (3, 6 or 12 months),
  vitals (with a °F/°C setting), diagnostic list, profile, lab results with downloads.
- **Overview, Schedule, Message, Transactions**: working pages with filtering, sorting, and a
  messaging thread you can reply in.
- Loading skeletons, error and empty states, a retry button, a request timeout and an error boundary.
- Accessible by default: native `<dialog>` modals, keyboard-navigable menus, skip link,
  visible focus, `aria-current` navigation, reduced-motion support.
- Responsive: three columns from 1280px, two from 1024px, one below.

## Data

| Section | Source |
| --- | --- |
| Patients, vitals, blood pressure, diagnoses, lab results, profile | Coalition Technologies Patient Data API (real) |
| Overview "Needs attention" list | Derived from the API data |
| Schedule, Message, Transactions, Overview stat cards | Mock data in `src/data/` (the API has none) |

The mock data points at real patients by position, so names, photos and links stay consistent.

## Run it

Requires Node.js 20+.

    npm install
    npm run dev        # http://localhost:5173
    npm run build      # production build in dist/
    npm run preview    # serve the production build locally

Optional: copy `.env.example` to `.env` to point at a different API.

## Deploy

It is a static single-page app, so any static host works. The routes use the History API, so the
host must serve `index.html` for unknown paths. `vercel.json` and `public/_redirects` already do this.

- **Vercel:** import the repo, framework preset *Vite*, build `npm run build`, output `dist`.
- **Netlify:** build `npm run build`, publish directory `dist`.

## Structure

    src/
      main.jsx, App.jsx        entry and routes
      components/              Header, Layout, skeletons, error states
        patient/               dashboard cards (chart, vitals, lists, profile)
        dialogs/, ui/          modals, menus, avatar, pills
      context/                 patients, settings and messages state
      hooks/                   usePatients, useSettings, useMessages, useDocumentTitle
      lib/                     API client, formatting, history helpers, errors
      data/                    mock schedule, messages and transactions
      pages/                   one file per route
