import { useEffect, useState } from 'react';
import { fetchPatients } from './lib/api.js';
import logo from './assets/images/logo.png';

// Temporary smoke test for Step 1: proves Tailwind tokens, assets and the API all work.
// Step 2 replaces this with the real shell and routes.
export default function App() {
  const [state, setState] = useState({ status: 'loading' });

  useEffect(() => {
    const controller = new AbortController();
    fetchPatients(controller.signal)
      .then((patients) => setState({ status: 'ready', count: patients.length }))
      .catch((error) => {
        if (error.name !== 'AbortError') setState({ status: 'error', message: error.message });
      });
    return () => controller.abort();
  }, []);

  return (
    <main className="mx-auto mt-10 max-w-[600px] card p-8 text-center">
      <img src={logo} alt="Tech.Care" className="mx-auto w-[208px]" />
      <h1 className="mt-6 text-card-title">React setup works</h1>
      <p className="mt-3" role="status">
        {state.status === 'loading' && 'Loading patients…'}
        {state.status === 'ready' && `API connected: ${state.count} patients loaded.`}
        {state.status === 'error' && `API error: ${state.message}`}
      </p>
      <span className="mt-6 inline-block rounded-full bg-teal px-5 py-2 font-bold">Teal token</span>
    </main>
  );
}
