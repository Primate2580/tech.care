import { Link, Navigate, useParams } from 'react-router';
import { usePatients } from '../hooks/usePatients.js';
import { useDocumentTitle } from '../hooks/useDocumentTitle.js';
import { findBySlug, slugify } from '../lib/patients.js';

const DEFAULT_PATIENT = 'Jessica Taylor';

/** /patients -> redirect to the default patient's page once the list has loaded. */
export function PatientsIndex() {
  const { status, patients } = usePatients();
  useDocumentTitle('Patients');

  if (status === 'loading') return <p role="status">Loading patients…</p>;
  if (status === 'error' || patients.length === 0) return null; // Layout shows the error banner

  const target = patients.find((p) => p.name === DEFAULT_PATIENT) ?? patients[0];
  return <Navigate to={`/patients/${slugify(target.name)}`} replace />;
}

/** /patients/:slug - placeholder until the full dashboard in Step 3. */
export function PatientPage() {
  const { slug } = useParams();
  const { status, patients } = usePatients();
  const patient = findBySlug(patients, slug);
  useDocumentTitle(patient?.name ?? 'Patients');

  if (status === 'loading') return <p role="status">Loading patient…</p>;
  if (status === 'error') return null;

  if (!patient) {
    return (
      <main className="card px-5 py-[22px]">
        <h1 className="text-card-title">Patient not found</h1>
        <Link to="/patients" className="mt-6 inline-block rounded-full bg-teal px-5 py-2 font-bold">
          Back to patients
        </Link>
      </main>
    );
  }

  return (
    <main className="card px-5 py-[22px]">
      <h1 className="text-card-title">{patient.name}</h1>
      <p className="mt-4 text-muted">
        {patient.gender}, {patient.age}. The full dashboard is built in Step 3.
      </p>
    </main>
  );
}
